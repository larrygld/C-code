package com.ttit.helloworld.entity;

public class Group {
    private String gName;

    public Group() {
    }

    public Group(String gName) {
        this.gName = gName;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }
}
